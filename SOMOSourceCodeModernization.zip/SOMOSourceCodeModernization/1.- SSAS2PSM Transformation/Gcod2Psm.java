package juntos3psm;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;

import javax.swing.JButton;

import  javax.swing.*;

//import java.awt.FileDialog;
import java.awt.Frame;

import java.awt.Rectangle;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.io.File;

import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;
import java.awt.SystemColor;
import java.awt.Dimension;
import java.awt.event.KeyEvent;

public class Gcod2Psm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JPanel jPanel = null;
	private JButton jButton = null;
	private JTextArea jTextArea = null;
	private JScrollPane jScrollPane = null;
	private String arch[];
	private JButton Generar = null;
	private JLabel Ruta = null;
	private JLabel tituloRuta = null;
	private JButton bSalir = null;
	/**
	 * This is the default constructor
	 */
	public Gcod2Psm() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(607, 294);
		this.setResizable(false);
		this.setContentPane(getJContentPane());
		this.setTitle("Cod2Psm");
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0); 
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJPanel(), BorderLayout.CENTER);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			tituloRuta = new JLabel();
			tituloRuta.setBounds(new Rectangle(19, 205, 186, 16));
			tituloRuta.setText("Ruta Del Modelo Generado");
			Ruta = new JLabel();
			Ruta.setBounds(new Rectangle(20, 224, 534, 17));
			Ruta.setText("...");
			jPanel = new JPanel();
			jPanel.setLayout(null);
			jPanel.add(getJButton(), null);
			jPanel.add(getJScrollPane(), null);
			jPanel.add(getGenerar(), null);
			jPanel.add(Ruta, null);
			jPanel.add(tituloRuta, null);
			jPanel.add(getBSalir(), null);
		}
		return jPanel;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(405, 53, 147, 28));
			jButton.setText("Seleccionar  PSM");
			jButton.setToolTipText("Seleccionar los archivos");
			jButton.setName("Mostrar");
		
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
				

				
					Frame marco= new Frame();
					JFileChooser jfcExaminarEntrada= new JFileChooser();
					jfcExaminarEntrada.setFileFilter(new FiltroPsm());
					jfcExaminarEntrada.setCurrentDirectory(new File ("."));
					jfcExaminarEntrada.setApproveButtonText("Seleccionar");
					jfcExaminarEntrada.setDialogTitle("Seleccion de archivos PSM");
					jfcExaminarEntrada.cancelSelection();
			
					jfcExaminarEntrada.setMultiSelectionEnabled(true);
					//jfcExaminarEntrada.showOpenDialog(marco);
					int returnVal = jfcExaminarEntrada.showOpenDialog(marco);

					//si presiona el boton cancelar no hace nada
		            if (returnVal != JFileChooser.APPROVE_OPTION){
		                return;
		            }
					
					File[] files = jfcExaminarEntrada.getSelectedFiles();

					//arch=jfcExaminarEntrada.getSelectedFile();
					jTextArea.setText("");

					arch= new String[files.length];

					for(int i=0;i<files.length;i++){

						Generar.setEnabled(true);
//						System.out.println(files[i].toString());
//						System.out.println(files[i].getName());
						jTextArea.append(files[i].toString()+ '\n');
						arch[i]=files[i].toString();
					}
					
				//	 FileDialog filAbrir = new FileDialog (marco,"Abrir archivo", FileDialog.LOAD);
					
					//  filAbrir.setFilenameFilter(new FiltroPsm());
					 
					 
//					  filAbrir.show();
//					  System.out.println(filAbrir.getFile());
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jTextArea	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
			jTextArea.setLineWrap(false);
			jTextArea.setText("");
			jTextArea.setEditable(false);
		}
		return jTextArea;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(20, 46, 373, 152));
			jScrollPane.setBorder(BorderFactory.createLineBorder(SystemColor.activeCaption, 5));
			jScrollPane.setViewportView(getJTextArea());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes Generar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getGenerar() {
		if (Generar == null) {
			Generar = new JButton();
			Generar.setBounds(new Rectangle(404, 88, 150, 27));
			Generar.setText("Generar Modelo");
			Generar.setToolTipText("Generar Modelo PSM configuracion de psm");
			Generar.setEnabled(false);
			Generar.setName("Transformar");
			Generar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Frame marco= new Frame();
					JFileChooser fileGuardar= new JFileChooser();
					fileGuardar.setFileFilter(new FiltroPsmPsm());
					fileGuardar.setCurrentDirectory(new File("."));
					
					int result = fileGuardar.showSaveDialog(marco);
			        if(result == JFileChooser.APPROVE_OPTION) {
			            String path = fileGuardar.getSelectedFile().getAbsolutePath();
			            if (!path.endsWith(".psm")){
			            	path+=".psm";
			            	
			            }
			            Cod2PsmG p = new Cod2PsmG(arch,path);
						p.GenerarModelo();
						Ruta.setText(p.GetRuta());
						
			            JOptionPane.showMessageDialog(marco,
			                    "Archivo Creado '"+path+"'",
			                    "Archivo Guardado",
			                    JOptionPane.INFORMATION_MESSAGE);
			        } else {
			            JOptionPane.showMessageDialog(marco,
			                    "No seleccion� ning�n archivo",
			                    "Di�logo cerrado o cancelado",
			                    JOptionPane.INFORMATION_MESSAGE);
			        }
			        
					
				}
			});
		}
		return Generar;
	}

	/**
	 * This method initializes bSalir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBSalir() {
		if (bSalir == null) {
			bSalir = new JButton();
			bSalir.setBounds(new Rectangle(405, 125, 149, 26));
			bSalir.setText("Salir");
			bSalir.setName("bSalir");
			bSalir.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.exit(0); 
				}
			});
		}
		return bSalir;
	}

}  //  @jve:decl-index=0:visual-constraint="119,67"
