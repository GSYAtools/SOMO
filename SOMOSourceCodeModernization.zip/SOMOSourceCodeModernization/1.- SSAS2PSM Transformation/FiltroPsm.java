package juntos3psm;

import java.io.File;

public class FiltroPsm extends javax.swing.filechooser.FileFilter{
	public boolean accept(File file) {
    //    String filename = file.getName();
   //     return filename.endsWith(".psm |.txt");
        return file.isDirectory() || file.getName().toLowerCase().endsWith(".role")
        || file.getName().toLowerCase().endsWith(".cube") || file.getName().toLowerCase().endsWith(".dim");

    }
    public String getDescription() {
        return "*.*";
    }

	

}