package juntos3psm;

import java.io.File;

public class FiltroPsmPsm extends javax.swing.filechooser.FileFilter{
	public boolean accept(File file) {
    //    String filename = file.getName();
   //     return filename.endsWith(".psm |.txt");
        return file.isDirectory() || file.getName().toLowerCase().endsWith(".psm");

    }
    public String getDescription() {
        return "*.psm";
    }

	

}
