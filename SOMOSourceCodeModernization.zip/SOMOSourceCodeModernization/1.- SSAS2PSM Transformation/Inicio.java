package juntos3psm;


public class Inicio {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gcod2Psm psm=new Gcod2Psm();
		psm.show(true);

	}

}
