package juntos3psm;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import org.jdom.*;
import org.jdom.input.*;

public class Cod2PsmG {

	
	Integer miembros;
	String Miembro;
	String raizT;
	String cabeceraT;
	String cuerpo;
	
	String SchemaT;
	String rolesT;
	String rolMemberT;
	List <String> lirolM;
	
	String cubesT;
	String cubPermT=null;
	String cubRegT;
	List <String> licubR;
	String crMemT;
	List <String> licrM;
	
	String dimensionT;
	String dimPermT;
	List <String> lidip;
	String levT;
	List <String> lile;
	String dimMem1T;
	String dimMemNT;
	List<String> lidimNT;
	String hierT;
	List <String> lihi;

	List <String> rolesF = new LinkedList<String>();
	List <String> dimF = new LinkedList<String>();
	List <String> cubesF = new LinkedList<String>();
	List <String> memCubF = new LinkedList<String>();
	List <String> memDimF = new LinkedList<String>();

	List <String> memPerF = new LinkedList<String>();
	Map<Integer,Integer> tamDimF = new HashMap<Integer,Integer>();
		
	String memPermT;
	String memCPermT;
	
	String RolFile = "SP";
	String nomModelo; // = "Modelos/cod2RolG.rolpsm";
	//String metamodelo = "../metamodelos/rolPsm.ecore";
	String ListaArchivos[];
	String dwName="DW";

	public Cod2PsmG(String lista[],String saveFile) {
		ListaArchivos = lista;
		nomModelo=saveFile;

	}
	public String GetRuta(){
		return nomModelo;
	}

	public void GenerarModelo() {
		try {
			if(ListaArchivos.length>0){
				FileWriter fw = new FileWriter(nomModelo);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter salida = new PrintWriter(bw);
				/********************************************************************/
				cabeceraT = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
				raizT = "<psm:Schema xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:xsi=\"http:" +
						"//www.w3.org/2001/XMLSchema-instance\" xmlns:psm=\"http://psm/1.0\" xsi:schemaLocation" +
						"=\"http://psm/1.0 ../metamodelos/PSM.ecore\">"; //Cabecera valida para transformar posteriormente a QVT
								
	
				salida.println(cabeceraT);
				salida.println(raizT);
				int rolX = 0, cubX = 0, dimX = 0;
				int diPerX = 0, hiX = 0, mePerX = 0;
				int cuPerX = 0;
				
				/********************************************************************/
				iniciaTodo();	//Llamada al metodo auxiliar que inicializa todo para futuras busquedas
				
				for (int numArch = 0; numArch < ListaArchivos.length; numArch++) {
					SAXBuilder builder = new SAXBuilder(false);
					Document doc = builder.build(ListaArchivos[numArch]);
					
					Element raiz = doc.getRootElement();
					String nomRaiz = raiz.getName();
					
					//------ROLES---------
					if(nomRaiz.equals("Role"))
					{
						int numRols = raiz.getChildren().size();
						int c=0;
						Element rolid = null, rolname = null, rolmem=null; //Elementos para Role
						Element rmid = null, rmna = null; //Elementos para RoleMember
						lirolM = new LinkedList<String>();
						//Recorrido de los elementos de Role
						for(int i=0;i<numRols;i++)
						{
							if( ((Element) raiz.getChildren().get(i)).getName().equals("ID") )
								rolid = (Element) raiz.getChildren().get(i);
							if( ((Element) raiz.getChildren().get(i)).getName().equals("Name") )
								rolname = (Element) raiz.getChildren().get(i);
							if(((Element) raiz.getChildren().get(i)).getName().equals("RoleMembers")) //Creacion de RoleMembers
							{												
								//-------------ROLEMEMBER
								rolmem = (Element) raiz.getChildren().get(i);
								List listrolmem = rolmem.getChildren();
								
								if(listrolmem.size() > 0)
								{
									Iterator i1c = listrolmem.iterator();
									while (i1c.hasNext())
									{
										Element rolm = (Element) i1c.next();
										
										//Recorrido de los RoleMembers dentro del mismo Rol
										for(int j=0;j<rolm.getChildren().size();j++)
										{
											if(((Element) rolm.getChildren().get(j)).getName().equals("ID"))
											{
												rmid = (Element) rolm.getChildren().get(j);
											}
											if(((Element) rolm.getChildren().get(j)).getName().equals("Name"))
											{
												rmna = (Element) rolm.getChildren().get(j);
											}
										}//ffor cregmem
										rolMemberT = "   <ownedRoleMembers rmID=\"" + rmid.getText().replaceAll(" ","")+ "\" rmName=\""+ rmna.getText().replaceAll(" ","") +"\"/>";
										lirolM.add(rolMemberT);
										c=1;
									}//fwhile i1c
								}//fif listrolmem
							}//fif RoleMembers
	
						}
						rolesT = " <ownedRoles roleID=\"" + rolid.getText() + "\" roleName=\"" + rolname.getText()+"\" ownedSchema=\"/\"";

						if(c==0) //No hay RoleMember
							rolesT+="/>";
						else //Si les hay
							rolesT+=">";
						
						salida.println(rolesT);
						
						//Recorrer lista de RoleMember para pintar
						for(int p=0;p<lirolM.size();p++)
						{
							String aux = lirolM.get(p);
							salida.println(aux);
						}	
						if(c==1)
							salida.println("</ownedRoles>");

					}
					
					
					
					//-------CUBES-------
					if(nomRaiz.equals("Cube"))
					{
						int numCubs = raiz.getChildren().size();
						int v1=0, v2=0, v3=0;
						int cuReX = 0;
						licubR = new LinkedList<String>();
						licrM = new LinkedList<String>();
						Element cubeid = null, cubename = null, cubper = null, cubreg = null, cubdim = null; //Para cube
						Element cubpid = null, cubpna = null, cubpro = null, cubpred = null, cubpdp = null,  cubpal = null, cubproc = null; //Para cubePermission
						Element cbrid = null, cbrnam = null, cregmemb = null; //Para cubeRegion
						Element cbrmid = null, cbrmna = null; //Para CubeRegionMember
						Element cdid = null;
						int auxDim = 0;
						String auxT = " ownedDimensions=\"";
						//Recorrido de los elementos del cubo
						for(int i=0;i<numCubs;i++)
						{
							if( ((Element) raiz.getChildren().get(i)).getName().equals("ID") )
							{
								cubeid = (Element) raiz.getChildren().get(i);
								cubesT = " <ownedCubes cubeID=\"" + cubeid.getText().replaceAll(" ","") + "\"";
							}
							if( ((Element) raiz.getChildren().get(i)).getName().equals("Name") )
							{
								cubename = (Element) raiz.getChildren().get(i);
								 cubesT+=" cubeName=\"" + (cubename.getText()).replaceAll(" ","")+"\" " +
								"ownedSchema=\"/\"";
							}
							if( ((Element) raiz.getChildren().get(i)).getName().equals("CubePermissions") )
							{
								
																
								//------CUBEPERMISSION
								cubper = (Element) raiz.getChildren().get(i);
								SecPerm scC = new SecPerm();
								
								LinkedList<String> auxre = new LinkedList<String>();
								LinkedList<String> auxpo = new LinkedList<String>();								
								
								List listCubPer = cubper.getChildren();
								if(listCubPer.size() > 0)
								{
									Iterator i8 = listCubPer.iterator();
									Iterator i8aux = listCubPer.iterator();
									Element auxdper = (Element) i8aux.next();
									LinkedList<SecPerm> listsec = new LinkedList<SecPerm>();
									LinkedList<Integer> po = new LinkedList<Integer>();
									LinkedList<Integer> re = new LinkedList<Integer>();


									int posC = 0;
									
									while (i8.hasNext())
									{
										Element cubperms = (Element) i8.next();
										po.add(0);
										re.add(0);
										
										//Recorrido de los elementos del CubePermission
										for(int j=0;j<cubperms.getChildren().size();j++)
										{
											if(((Element) cubperms.getChildren().get(j)).getName().equals("ID"))
											{
												cubpid = (Element) cubperms.getChildren().get(j);
												scC.idSet(cubpid.getText(),posC);
											}
											if(((Element) cubperms.getChildren().get(j)).getName().equals("Name"))
											{
												cubpna = (Element) cubperms.getChildren().get(j);
												scC.naSet(cubpna.getText(), posC);
											}	
											
											if(((Element) cubperms.getChildren().get(j)).getName().equals("RoleID"))
											{
												cubpro = (Element) cubperms.getChildren().get(j);
												//Busqueda de los roles para asignarles una posicion
												if(buscaRol(cubpro.getText()))	//Lo pone en formato @ownedRoles.0
												{
													cubpro.setText("//@ownedRoles."+ponNumRol(cubpro.getText()));
													scC.rolSet(cubpro.getText(), posC);
												}
												else{
													scC.rolSet(cubpro.getText(), posC);
												}
												
											}
											if(((Element) cubperms.getChildren().get(j)).getName().equals("Read"))
											{
												cubpred = (Element) cubperms.getChildren().get(j);
												//Si el valor de read es Allowed = true, si no = falso
												if(cubpred.getText().equals("Allowed"))
													cubpred.setText("true");
												else
													cubpred.setText("false");
												re.pollLast();
												re.add(1);	//Comprobacion futura para determinar si esta el read
												scC.read(cubpred.getText(), posC);
											}
											
											if(((Element) cubperms.getChildren().get(j)).getName().equals("Process"))
											{
												cubproc = (Element) cubperms.getChildren().get(j);
												po.pollLast();	
												po.add(1);	//Comprobacion futura para determinar si esta el process
												scC.poSet(cubproc.getText(), posC);
											}
											if(((Element) cubperms.getChildren().get(j)).getName().equals("CellPermissions"))
											{
												//------CELLPERMISSION
												cubpdp = (Element) cubperms.getChildren().get(j);
												List listcpdp = cubpdp.getChildren();
												if(listcpdp.size() > 0)
												{
													Iterator i10 = listcpdp.iterator();
													while (i10.hasNext())
													{
														Element cpdp = (Element) i10.next();
														
														//Recorrida de los elementos de CellPermission
														for(int k=0;k<cpdp.getChildren().size();k++)
														{											
															if(((Element) cpdp.getChildren().get(k)).getName().equals("Expression"))
															{
																cubpal = (Element) cpdp.getChildren().get(k);
																scC.alSet(cubpal.getText(), posC); //Lo a�ade al allowedSet del CubePermission
															}
														}//ffor cellpermission

													}//fwhile i10
												}//fif listaCellPermission
											}//fif CellPermission
																		
											
																		
										}//ffor cubperms	
										if(re.getLast()==0){ //Poner el read de CubePermission a false en caso de que no haya read
											scC.read("false", posC);
										}
										if(po.getLast()==0){ //Poner el process de CubePermission a false
											scC.poSet("false",posC);
										}

										//Si es el primer CubePermission a�ade todos los elementos
										if(posC==0)
										{
											listsec.add(scC);
											auxre.add(scC.lr.get(posC));
											auxpo.add(scC.lp.get(posC));
											scC.posicion(posC);
										}
										else
										{
											int entra=0;
											for(int hh=0;hh<posC;hh++)
											{
												//Comprueba si ya existe un read y un process
												if( (scC.lr.get(posC).equals(scC.lr.get(hh))) && (scC.lp.get(posC).equals(scC.lp.get(hh))) )
												{
													entra=1;
													break;
												}
											}
											//En caso de que no existan, crea un nuevo CubePermission
											if(entra==0)
											{
												listsec.add(scC);
												auxre.add(scC.lr.get(posC));
												auxpo.add(scC.lp.get(posC));
												scC.posicion(posC);
											}
										}
										
										posC++;
									}//fwhile iter8
									
									
									cubesT+=" ownedCubePermissions=\"";
									
									//Recorrida de la lista de CubePermission para pintarles
									for(int ll=0;ll<listsec.size();ll++)
									{
										cubPermT = " <AuxCubePermissions spID=\"" +(listsec.get(ll).li.get(listsec.get(ll).lpos.get(ll))+"-"+cubeid.getText()).replaceAll(" ","")+"\" spName=\"" + (listsec.get(ll).ln.get(listsec.get(ll).lpos.get(ll))+"-"+cubename.getText()).replaceAll(" ","")+"\"";
										if(scC.lrol.size()>0)
										{
											cubPermT+=" roleID=\"";
											for(int ff=0;ff<scC.lrol.size();ff++) //Poner la lista de roles en el CubePermission
											{
												if( listsec.get(ll).lr.get(listsec.get(ll).lpos.get(ll)).equals(scC.lr.get(ff)) &&
														listsec.get(ll).lp.get(listsec.get(ll).lpos.get(ll)).equals(scC.lp.get(ff)))
												{
													cubPermT+=listsec.get(ll).lrol.get(ff)+" ";
												}	
											}
											cubPermT+="\"";
										}
									if(listsec.get(ll).lr.get(listsec.get(ll).lpos.get(ll)).equals("true")) //Solo pinta read si esta a true
										cubPermT+=" read=\""+listsec.get(ll).lr.get(listsec.get(ll).lpos.get(ll))+"\"";
									try{
										if( !(listsec.get(ll).la.get(listsec.get(ll).lpos.get(ll)).equals(" ")) ) //Solo pinta si allowed tiene valor
										{
											String remplazado = reemplaza(listsec.get(ll).la.get(listsec.get(ll).lpos.get(ll)));
											cubPermT+=" allowedSet=\""+remplazado+"\"";
										}
									}catch(Exception e){}

									cubPermT+=" ownedCube=\"//@ownedCubes."+cubX+"\"";	
									cubPermT+="/>";
									salida.println(cubPermT);		
									
									cubesT+="//@AuxCubePermissions."+cuPerX+" ";
									cuPerX++;
									}//ffor recorrida CubePermission
									cubesT+="\"";
									
								
									
								}//fif listCubPers
							}//fif getName=CubePermission
							
							if( ((Element) raiz.getChildren().get(i)).getName().equals("MeasureGroups") )
							{
								v1=1;
								//---------------CUBEREGION = MEASUREGROUPS
								cubreg = (Element) raiz.getChildren().get(i);
								List listcubreg = cubreg.getChildren();
								if(listcubreg.size() > 0)
								{
									Iterator i9 = listcubreg.iterator();
									
									
									while (i9.hasNext())
									{
										Element cbreg = (Element) i9.next();
										
										//Recorrer los elementos del MeasureGroups
										for(int j=0;j<cbreg.getChildren().size();j++)
										{
											if(((Element) cbreg.getChildren().get(j)).getName().equals("ID"))
											{
												cbrid = (Element) cbreg.getChildren().get(j);
											}
											cubRegT = "  <ownedCubeRegions crID=\"" + cbrid.getText().replaceAll(" ","")+"\"";
											if(((Element) cbreg.getChildren().get(j)).getName().equals("Name"))
											{
												cbrnam = (Element) cbreg.getChildren().get(j);
											}
											try{
												cubRegT+=" crName=\""+ cbrnam.getText().replaceAll(" ","") +"\"";
											}catch(Exception e){}
											cubRegT+=" ownedCube=\"//@ownedCubes."+cubX+"\"";

											if(((Element) cbreg.getChildren().get(j)).getName().equals("Measures"))
											{
												v2=1;												
												//-------------CUBEREGIONMEMBER = MEASURES
												cregmemb = (Element) cbreg.getChildren().get(j);
												List listcregmem = cregmemb.getChildren();
												
												if(listcregmem.size() > 0)
												{
													Iterator i10 = listcregmem.iterator();
													while (i10.hasNext())
													{
														Element cregmem = (Element) i10.next();
														
														//Recorrida de los elementos de Measures
														for(int k=0;k<cregmem.getChildren().size();k++)
														{
															if(((Element) cregmem.getChildren().get(k)).getName().equals("ID"))
															{
																cbrmid = (Element) cregmem.getChildren().get(k);
															}
															if(((Element) cregmem.getChildren().get(k)).getName().equals("Name"))
															{
																cbrmna = (Element) cregmem.getChildren().get(k);
															}
														}//ffor cregmem
														crMemT = "   <ownedMembers memberID=\"" + cbrmid.getText().replaceAll(" ","")+ "\" memberName=\""+ cbrmna.getText().replaceAll(" ","") +"\" " +
																"ownedCubeRegions=\"//@ownedCubes."+cubX+"/@ownedCubeRegions."+cuReX;
														if(buscaMemP(cbrmid.getText())) //Si existe un MemberPermision para el CubeRegion le pinta (relacion 1-1)
														{
															crMemT+=" ownedMemberPermissions=\"//@AuxMemberPermissions."+ponNumMemP(cbrmid.getText())+" ";
														}
														crMemT+="\"/>";
														licrM.add(crMemT);
														v3++;

													}//fwhile i10
												}//fif listcregmem
											}//fif Measures
										}//ffor cbreg
										cuReX++;
										licubR.add(cubRegT); //A�ador el CubeRegion a una lista de ellos para pintarlo posteriormente
									}//fwhile i9
								}//fif listcubreg
							}//fif MeasureGroups	
							
							//DIMENSION EN CUBE
							if( ((Element) raiz.getChildren().get(i)).getName().equals("Dimensions") )
							{
								cubdim = (Element) raiz.getChildren().get(i);
								List listcubdim = cubdim.getChildren();
								if(listcubdim.size() > 0)
								{
									Iterator i9 = listcubdim.iterator();
									
									while (i9.hasNext())
									{
										Element cd = (Element) i9.next();

										for(int j=0;j<cd.getChildren().size();j++)
										{
											if(((Element) cd.getChildren().get(j)).getName().equals("ID"))
											{

												cdid = (Element) cd.getChildren().get(j);
												if(buscaDim(cdid.getText()))
												{

													auxDim=1;
													auxT+="//@ownedDimensions."+ponNumDim(cdid.getText())+" ";
												}
											}
											
										}//ffor cbreg
									}//fwhile i9
									
								}//fif listcubdim
							}//fif Dimensions en Cube
							
							
						}
						
						//Condiciones bajo las que se pinta los atributros del cubo
						if(auxDim==1)
						{
							cubesT+=auxT+"\"";

						}
						if(v1==1) //Comprobacion para los hijos
						{
							cubesT+=">";
							
						}
						else
							cubesT+="/>";
						salida.println(cubesT);
						
						//Recorrer lista de CubeRegionMember para pintarlos
						for(int p=0;p<cuReX;p++)
						{
							String aux = licubR.get(p);
							if(v2==1) //Comprobacion para los hijos
							{
								aux+=">";
							}
							else
								aux+="/>";
							salida.println(aux);
									
							for(int l=0;l<v3;l++)
							{
								salida.println(licrM.get(l));	
							}
							
							if(v2==1)
								salida.println("  </ownedCubeRegions>");

						}						
						if(v1==1)
							salida.println(" </ownedCubes>");
						
						cubX++;
					}
					
					
					
					
					//------DIMENSION---------
					if(nomRaiz.equals("Dimension"))
					{
						int v1=0, v2=0;
						int posic=0;
						
						lidimNT = new LinkedList<String>();
						lidip = new LinkedList<String>();
						lihi = new LinkedList<String>();
						lile = new LinkedList<String>();
					
						int numDims = raiz.getChildren().size();
						Element dimid = null, dimname = null, dimper = null, dimmem = null, hier = null; //Para dimension
						Element dimpermid = null, dimpermname = null, dimpermrid = null, dimpermread = null, dimpermatt = null, auxread = null;
						Element dimperal = null, dimperde=null, auxal = null, auxde=null, dimperpo;
						Element dimmemid = null, dimmemna = null;
						Element hid = null, hna = null, hle = null;
						Element lid = null, lna = null;
						Element mempermdns = null, memperid = null, mempermal = null;

						//Recorrer los elementos de la dimension
						for(int i=0;i<numDims;i++)
						{
							if( ((Element) raiz.getChildren().get(i)).getName().equals("ID") ){
								dimid = (Element) raiz.getChildren().get(i);
								dimensionT=" <ownedDimensions dimensionID=\"" + (dimid.getText()).replaceAll(" ","")+"\"";
							}
							if( ((Element) raiz.getChildren().get(i)).getName().equals("Name") ){
								dimname = (Element) raiz.getChildren().get(i);
								dimensionT+=" dimensionName=\"" + (dimname.getText()).replaceAll(" ","")+"\" ownedSchema=\"/\"";
								if(buscaDim(dimid.getText())) //En caso de que ya exista la dimension
								{
									if(ponNumCub(dimid.getText()).size()>0) //Si existen cubos para la dimension
									{
										dimensionT+=" ownedCubes=\"";
										for(int ii=0;ii<ponNumCub(dimid.getText()).size();ii++)
											dimensionT+="//@ownedCubes."+ponNumCub(dimid.getText()).get(ii)+" "; //Pone el numero de cubo asignado a la dimension
										dimensionT+="\"";
									}
								}
							}
							
							if( ((Element) raiz.getChildren().get(i)).getName().equals("DimensionPermissions") )
							{
								//dimensionT=" <ownedDimensions dimensionID=\"" + (dimid.getText()).replaceAll(" ","")+"\" dimensionName=\"" + (dimname.getText()).replaceAll(" ","")+"\" ownedSchema=\"/\"";
								
								
								//------DIMENSIONPERMISSION
								dimper = (Element) raiz.getChildren().get(i);
								List listDimPer = dimper.getChildren();
								SecPerm sc = new SecPerm();
								MemPerm mp = new MemPerm();

								LinkedList<String> auxre = new LinkedList<String>();
								LinkedList<String> auxpo = new LinkedList<String>();
								LinkedList<Integer> auxat = new LinkedList<Integer>();


								LinkedList<String> auxalm = new LinkedList<String>();
								LinkedList<String> auxdem = new LinkedList<String>();
								LinkedList<String> auxidm = new LinkedList<String>();
								LinkedList<String> auxnam = new LinkedList<String>();


								

								if(listDimPer.size() > 0)
								{
									Iterator i11 = listDimPer.iterator();
									
									LinkedList<SecPerm> listsec = new LinkedList<SecPerm>();
									LinkedList<MemPerm> listmaux = new LinkedList<MemPerm>();

									LinkedList<MemPerm> listmem = new LinkedList<MemPerm>();
									
									LinkedList<Integer> po = new LinkedList<Integer>();

									int pos=0;
									int pmem=0;
									int tieneAtrib = 0;

									while (i11.hasNext())
									{
										tieneAtrib=0;
										po.add(0);
										Element dimperms = (Element) i11.next();
										dimperal = null;
										dimperde = null;
										int al=0;
										int de=0;
										LinkedList<Integer> alme = new LinkedList<Integer>();
										LinkedList<Integer> deme = new LinkedList<Integer>();
										//Recorrida de los elementos del DimensionPermission
										for(int j=0;j<dimperms.getChildren().size();j++)
										{
											if(((Element) dimperms.getChildren().get(j)).getName().equals("ID"))
											{
												dimpermid = (Element) dimperms.getChildren().get(j);
												sc.idSet(dimpermid.getText(),pos);
											}
											if(((Element) dimperms.getChildren().get(j)).getName().equals("Name"))
											{
												dimpermname = (Element) dimperms.getChildren().get(j);
												sc.naSet(dimpermname.getText(), pos);
											}
											if(((Element) dimperms.getChildren().get(j)).getName().equals("RoleID"))
											{
												dimpermrid = (Element) dimperms.getChildren().get(j);
												if(buscaRol(dimpermrid.getText())) //Para poner el rol en formato @ownedRoles.0
												{
													dimpermrid.setText("//@ownedRoles."+ponNumRol(dimpermrid.getText()));
													sc.rolSet(dimpermrid.getText(), pos);
												}
												else //Si no existe el rol lo pone de forma normal -> roleID = RoleX
												{
													sc.rolSet(dimpermrid.getText(), pos);
												}

											}
											if(((Element) dimperms.getChildren().get(j)).getName().equals("Read"))
											{
												dimpermread = (Element) dimperms.getChildren().get(j);
												if(dimpermread.getText().equals("Allowed"))	//Si es allowed lo pone a true
													dimpermread.setText("true");
												else
													dimpermread.setText("false");	//si no a false
												sc.read(dimpermread.getText(), pos);
											}
											if(((Element) dimperms.getChildren().get(j)).getName().equals("Process"))
											{
												dimperpo = (Element) dimperms.getChildren().get(j);
												po.pollLast();
												po.add(1);	//futura comprobacion
												sc.poSet(dimperpo.getText(), pos);
											}
											if(((Element) dimperms.getChildren().get(j)).getName().equals("AllowedSet"))
											{
												dimperal = (Element) dimperms.getChildren().get(j);
												al=1;	//futura comprobacion
												sc.alSet(dimperal.getText(), pos);
											}
											if(((Element) dimperms.getChildren().get(j)).getName().equals("DeniedSet"))
											{
												dimperde = (Element) dimperms.getChildren().get(j);
												de=1;	//futura comprobacion
												sc.dnSet(dimperde.getText(),pos);
											}
											
											
											if(((Element) dimperms.getChildren().get(j)).getName().equals("AttributePermissions"))
											{
												tieneAtrib = 1;
												//-----MEMBERPERMISSION = ATTRIBUTEPERMISSION
												dimpermatt = (Element) dimperms.getChildren().get(j);
												List listmper = dimpermatt.getChildren();
												
												if(listmper.size() > 0)
												{
													Iterator i12 = listmper.iterator();						
													int aux=0;
													//int elems=0;
													while (i12.hasNext())
													{
														alme.add(0);
														deme.add(0);
														mp.dimSet(dimpermname.getText(), pmem);
														Element memperms = (Element) i12.next();
														
														//Recorrida de los MemberPermission
														for(int k=0;k<memperms.getChildren().size();k++)
														{
															if(((Element) memperms.getChildren().get(k)).getName().equals("AttributeID"))
															{
																memperid = (Element) memperms.getChildren().get(k);
																mp.naSet(memperid.getText(),pmem);
															}
															if(((Element) memperms.getChildren().get(k)).getName().equals("DeniedSet"))
															{
																mempermdns = (Element) memperms.getChildren().get(k);
																deme.pollLast();
																deme.add(1);
																mp.dnSet(mempermdns.getText(),pmem);

															}
															if(((Element) memperms.getChildren().get(k)).getName().equals("AllowedSet"))
															{
																mempermal = (Element) memperms.getChildren().get(k);
																alme.pollLast();
																alme.add(1);
																mp.alSet(mempermal.getText(), pmem);

															}
														
															try{if(buscaMemDim(memperid.getText())  && aux==0)	//El aux=0 indica que el miembro aun no ha sido tratado
															{
																for(int dd=0;dd<ponNumDim(dimid.getText());dd++)
																{
																	posic+=tamDimF.get(dd);
																}
																if((ponNumMemDim(memperid.getText()))==0)	//Si es el primer miembro -> Key Member
																{
																	aux=1;
																	mp.memSet(" ownedMember=\"//@ownedDimensions."+ponNumDim(dimid.getText())+"/@ownedKeyMember\"", pmem);
																}
																else{ //si no, es un Member Normal
																	aux=1;
																	mp.memSet(" ownedMember=\"//@ownedDimensions."+ponNumDim(dimid.getText())+"/@ownedMembers."+(ponNumMemDim(memperid.getText())-1)+"\"", pmem); //con -1 es porque el primer miembro es Key y el 2� .0...
																}
																if(ponNumDim(dimid.getText())!=0)	//Si no es la primera dimension 
																{
																	if((ponNumMemDim(memperid.getText()))%posic==0)	 //Para el key member, el % posic hace modulo para coger la posicion dentro de la dimension seleccionada
																	{
																		aux=1;
																		mp.memSet(" ownedMember=\"//@ownedDimensions."+ponNumDim(dimid.getText())+"/@ownedKeyMember\"", pmem);
																	}
																	else{
																		aux=1;
																		mp.memSet(" ownedMember=\"//@ownedDimensions."+ponNumDim(dimid.getText())+"/@ownedMembers."+((ponNumMemDim(memperid.getText())-1)%posic)+"\"", pmem);
																	}
																}
																
																
															}}catch(Exception e){}
															
															
														}//ffor numero memperm
														
														if(alme.getLast()==0){	//Para poner allowedSet nulo
															mp.alSet(" ",pmem);
														}
														if(deme.getLast()==0){	//Lo mismo con el deniedSet
															mp.dnSet(" ",pmem);
														}
														
														if(pmem==0) //Si es el primero a�ade todo el MemberPermission
														{
															listmaux.add(mp);
															
															auxalm.add(mp.la.get(pmem));
															auxdem.add(mp.ld.get(pmem));
															auxidm.add(mp.lmem.get(pmem));
															auxnam.add(mp.ln.get(pmem));

															mp.posicion(pmem);

														}
														else
														{
															int entra=0;
															for(int hh=0;hh<pmem;hh++)
															{
																//Si ya existe el nombre, denied, allowed y los member no entra despues
																if( (mp.ln.get(pmem).equals(mp.ln.get(hh))) && (mp.ld.get(pmem).equals(mp.ld.get(hh))) && 
																		(mp.la.get(pmem).equals(mp.la.get(hh))) && (mp.lmem.get(pmem).equals(mp.lmem.get(hh))) )
																{
																	
																	entra=1;
																	break;
																}
																	
															}
															if (entra==0) //En caso de que entre a�ade los elementos
															{
																listmaux.add(mp);
																auxidm.add(mp.lmem.get(pmem));
																auxnam.add(mp.ln.get(pmem));

																auxdem.add(mp.ld.get(pmem));
																auxalm.add(mp.la.get(pmem));
																mp.posicion(pmem);
															}
														}
														
														try{
															if(buscaRol(dimpermrid.getText())) //Busqueda de roles para el memberPermission
															{
																dimpermrid.setText("//@ownedRoles."+ponNumRol(dimpermrid.getText()));
																mp.rolSet(dimpermrid.getText(), pmem);
															}
															else
															{
																mp.rolSet(dimpermrid.getText(), pmem);
															}

														}catch(Exception e){}
														
														listmem.add(pmem, mp);

														mePerX++;
														pmem++;
														posic=0;
														aux=0;

													}//fwhile iter MemPerm
													
												}//fif lista memperm

											}//fif nombre=AttributePermision
											sc.memSet(listmem, pos); //A�ade MemPerm en SecPerm
																		
										}//ffor numero dimperm
										sc.tieneMem(tieneAtrib,pos); //Busca el memberPermission
										
										if(po.getLast()==0){
											sc.poSet("false",pos);
										}
										
										//Igual caso que para un MEmberPermission pero con distintos atributos
										if(sc.lm.get(pos)==0){
										if(pos==0)
											{
												listsec.add(sc);
												auxre.add(sc.lr.get(pos));
												auxpo.add(sc.lp.get(pos));
												auxat.add(sc.lm.get(pos));
												sc.posicion(pos);
											}
											else{
											int entra=0;
											for(int hh=0;hh<pos;hh++)
											{
												//Si ya existen no entra despues
												if( (sc.lr.get(pos).equals(sc.lr.get(hh))) && (sc.lp.get(pos).equals(sc.lp.get(hh))) && (sc.lm.get(pos).equals(sc.lm.get(hh))))
												{
													entra=1;
													break;
												}
													
											}
											if (entra==0)
											{
												listsec.add(sc);
												auxre.add(sc.lr.get(pos));
												auxpo.add(sc.lp.get(pos));
												auxat.add(sc.lm.get(pos));
												sc.posicion(pos);
											}
										}}
										
										
										pos++;
										
										
									}//fwhile dimPerm

									//Recorrida de los MemberPermission para pintarles si existen
									for(int mm=0;mm<listmaux.size();mm++)
									{		
										
										
										memPermT = " <AuxMemberPermissions mpName=\"MemberPermission"+(mm+"-"+dimname.getText()).replaceAll(" ","")+"\"";
										almacenaMemP(listmaux.get(mm).ln.get(listmaux.get(mm).lpos.get(mm)));
										
										memPermT+=listmaux.get(mm).lmem.get(listmaux.get(mm).lpos.get(mm));
										
										
											
										try{
										if( !(listmaux.get(mm).ld.get(listmaux.get(mm).lpos.get(mm)).equals(" ")) ) //Si el denied no es nulo
										{
											String aRemplazar=listmaux.get(mm).ld.get(listmaux.get(mm).lpos.get(mm));
											String remplazado=reemplaza(aRemplazar); //Para caracteres especiales
												memPermT+=" deniedSet=\"" +remplazado+"\"";
										}
										}catch(Exception e){}
										if( !(listmaux.get(mm).la.get(listmaux.get(mm).lpos.get(mm)).equals(" ")) ) //Si el allowed no es nulo
											memPermT+=" allowedSet=\"" + listmaux.get(mm).la.get(listmaux.get(mm).lpos.get(mm))+"\"";
										if(mp.lrol.size()>0)
										{
											memPermT+=" roleID=\"";
											for(int ff=0;ff<mp.lrol.size();ff++)
											{
												//Recorre los roles para pintarles si es mismo denied, allowed y Member
												if( listmaux.get(mm).ld.get(listmaux.get(mm).lpos.get(mm)).equals(mp.ld.get(ff)) &&
														listmaux.get(mm).la.get(listmaux.get(mm).lpos.get(mm)).equals(mp.la.get(ff)) &&
														listmaux.get(mm).lmem.get(listmaux.get(mm).lpos.get(mm)).equals(mp.lmem.get(ff)))
												{
													memPermT+=listmaux.get(mm).lrol.get(ff)+" ";
												}
											}
											memPermT+="\"";
										}
										
										mePerX++;
										memPermT+="/>";
										salida.println(memPermT);
									}
									
										dimensionT+=" ownedDimensionPermissions=\"";
										
										//Recorrer los dimensionPermission para pintarles. Se asemeja a un MemberPermission en su explicacion
										for(int ll=0;ll<listsec.size();ll++)
										{
											dimPermT = " <AuxDimensionsPermissions spID=\"" +(listsec.get(ll).li.get(listsec.get(ll).lpos.get(ll))+"-"+dimid.getText()).replaceAll(" ","")+"\" spName=\"" + (listsec.get(ll).ln.get(listsec.get(ll).lpos.get(ll))+"-"+dimname.getText()).replaceAll(" ","")+"\"";
											if(sc.lrol.size()>0)
											{
												dimPermT+=" roleID=\"";
												for(int ff=0;ff<sc.lrol.size();ff++)
												{
													if( listsec.get(ll).lr.get(listsec.get(ll).lpos.get(ll)).equals(sc.lr.get(ff)) &&
															listsec.get(ll).lp.get(listsec.get(ll).lpos.get(ll)).equals(sc.lp.get(ff)) &&
															sc.lm.get(ff) == 0)
													{
														dimPermT+=listsec.get(ll).lrol.get(ff)+" ";
													}	
												}
												dimPermT+="\"";
											}
										if(listsec.get(ll).lr.get(listsec.get(ll).lpos.get(ll)).equals("true")) //Solo pinta si esta a true
											dimPermT+=" read=\""+listsec.get(ll).lr.get(listsec.get(ll).lpos.get(ll))+"\"";
										dimPermT+=" ownedDimension=\"//@ownedDimensions."+dimX+"\"";										
										dimPermT+="/>";
										salida.println(dimPermT);		
										
										dimensionT+="//@AuxDimensionsPermissions."+diPerX+" ";
										diPerX++;
										}
										dimensionT+="\"";						
									
									
								}//fif listDimPers
							}//fif getName=DimensionPermission
							
							if( ((Element) raiz.getChildren().get(i)).getName().equals("Attributes") )
							{
								v1=1; //Comprobacion para hijos de dimension
								//------DIMENSIONMEMBER = ATTRIBUTES
								dimmem = (Element) raiz.getChildren().get(i);
								List listDimMem = dimmem.getChildren();
								if(listDimMem.size() > 0)
								{
									Iterator i13 = listDimMem.iterator();
									while (i13.hasNext())
									{
										Element dimmems = (Element) i13.next();
										int aux = 0; //Para ver si hay usageKey
										
										//Recorrida de los atributos
										for(int j=0;j<dimmems.getChildren().size();j++)
										{
											if(((Element) dimmems.getChildren().get(j)).getName().equals("ID"))
											{
												dimmemid = (Element) dimmems.getChildren().get(j);
											}
											if(((Element) dimmems.getChildren().get(j)).getName().equals("Name"))
											{
												dimmemna = (Element) dimmems.getChildren().get(j);
											}	
											if(((Element) dimmems.getChildren().get(j)).getName().equals("Usage"))
											{
												aux = 1; //1 indica que es key
											}
												
											
										}//ffor dimmems		
										try{		
											if(aux==1) //Si es Key pinta sus condiciones
											{
												dimMem1T = "  <ownedKeyMember memberID=\""+dimmemid.getText().replaceAll(" ","")+"\" memberName=\""+dimmemna.getText().replaceAll(" ","")+"\" " +
														"ownedDimension=\"//@ownedDimensions."+dimX+"\"";
												if(buscaMemP(dimmemid.getText())) //en caso de que tenga un MemberPermission asociado lo pinta
												{
													dimMem1T+=" ownedMemberPermissions=\"";
													for(int k=0;k<ponNumMemP(dimmemid.getText()).size();k++){
														dimMem1T+="//@AuxMemberPermissions."+ponNumMemP(dimmemid.getText()).get(k)+" ";

													}
													dimMem1T+="\"";
												}
												dimMem1T+="/>";
												aux=0;
											}
											//Para un member que no es Key, el resto es igual
											else
											{
												dimMemNT="  <ownedMembers memberID=\""+dimmemid.getText().replaceAll(" ","")+"\" memberName=\""+dimmemna.getText().replaceAll(" ","")+"\" " +
													"ownedDimension=\"//@ownedDimensions."+dimX+"\"";
												if(buscaMemP(dimmemid.getText()))
												{

													dimMemNT+=" ownedMemberPermissions=\"";
													for(int k=0;k<ponNumMemP(dimmemid.getText()).size();k++){
														dimMemNT+="//@AuxMemberPermissions."+ponNumMemP(dimmemid.getText()).get(k)+" ";

													}
													dimMemNT+="\"";

												}
												dimMemNT+="/>";
												lidimNT.add(dimMemNT);
												v2++;
											}
										}catch (Exception e){}
									}//fwhile iter8
								}//fif listDimMem
							}//fif getName=Attributes
							
							if( ((Element) raiz.getChildren().get(i)).getName().equals("Hierarchies") )
							{
								
							//------HIERARCHIES
							hier = (Element) raiz.getChildren().get(i);
							List listHier = hier.getChildren();
							if(listHier.size() > 0)
							{
								Iterator i14 = listHier.iterator();
								dimensionT+=" ownedHierarchies=\"";

								//Recorrer la lista de jerarquias para indicar cuales pertenecen a la dimension
								for (int a=0;a<listHier.size();a++)
								{
									dimensionT+="//@AuxHierarchies."+(a+hiX); 
								}
								dimensionT+="\"";
								int cuentaLevel=0;
								while (i14.hasNext())
								{
									Element hiers = (Element) i14.next();
									//Recorrida de los elementos de la jerarquia
									for(int j=0;j<hiers.getChildren().size();j++)
									{
										if(((Element) hiers.getChildren().get(j)).getName().equals("ID"))
										{
											hid = (Element) hiers.getChildren().get(j);
										}
										hierT = " <AuxHierarchies hierarchyID=\"" + hid.getText().replaceAll(" ","")+"\"";
										if(((Element) hiers.getChildren().get(j)).getName().equals("Name"))
										{
											hna = (Element) hiers.getChildren().get(j);
										}
										try{
											hierT+=" hierarchyName=\"" + hna.getText().replaceAll(" ","")+"\"";
										}catch(Exception e){}
										hierT+=" ownedDimension=\"//@ownedDimensions."+dimX+"\"";
										if(((Element) hiers.getChildren().get(j)).getName().equals("Levels"))
										{
											//-----LEVELS
											hle = (Element) hiers.getChildren().get(j);
											List listlev = hle.getChildren();
											
											if(listlev.size() > 0)
											{
												cuentaLevel=1;
												Iterator i15 = listlev.iterator();
												dimensionT+=" ownedLevels=\"";
												for (int b=0;b<listlev.size();b++)
												{
													dimensionT+="//@AuxHierarchies."+hiX+"/@ownedLevels."+b+" "; 
												}
												dimensionT+="\"";
												hierT+=">";
												salida.println(hierT);
												
												while (i15.hasNext())
												{
													Element levs = (Element) i15.next();

													//Recorrida de los elementos de los niveles
													for(int k=0;k<levs.getChildren().size();k++)
													{
														if(((Element) levs.getChildren().get(k)).getName().equals("ID"))
														{
															lid = (Element) levs.getChildren().get(k);
														}
														levT = "  <ownedLevels levelID=\"" + lid.getText().replaceAll(" ","")+"\"";
														if(((Element) levs.getChildren().get(k)).getName().equals("Name"))
														{
															lna = (Element) levs.getChildren().get(k);
														}
														try{
														levT+=" levelName=\"" + lna.getText().replaceAll(" ","")+"\"";}
														catch(Exception e){}
													}//ffor numerolevel
													levT+=" ownedHierarchies=\"//@AuxHierarchies."+hiX+"\" ownedDimension=\"//@ownedDimensions."+dimX+"\"/>";
													salida.println(levT);
												}//fwhile iter level
												salida.println(" </AuxHierarchies>");
											}//fif listalevel>0
										}						
									}//ffor numero jerarquias
									hiX++;//Aumenta jerarquia
									if(cuentaLevel==0)
									{
										hierT+="/>";
										salida.println(hierT);
									}
									cuentaLevel=0;
								}//fwhile iter jerarquia
							}//fif lista jerarquias>0
						}//fif getName=Hierarchies
							
							
							
					}
						if(v1==1) //Comprobacion para los hijos
						{
							dimensionT+=">";
						}
						else
							dimensionT+="/>";
						salida.println(dimensionT);
						if(v1==1)
							salida.println(dimMem1T);
						for(int a=0;a<v2;a++)
						{
							salida.println(lidimNT.get(a));
						}
						//MEMBERS
						if(v1==1)
							salida.println(" </ownedDimensions>");
						
						//Inicializar de neuvo para futuras llamadas*/
						dimX++;
					}
					
					
				}//fin for numArch
				salida.println("</psm:Schema>");
				salida.close();
					}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Guarda los roles en una lista
	 */
	public void almacenaRol(String text)
	{
		rolesF.add(text);
	}
	
	/**
	 * Guarda las dimensiones en una lista
	 */
	public void almacenaDim(String text)
	{
		dimF.add(text);
	}
	
	/**
	 * Guarda los cubos en una lista
	 */
	public void almacenaCub(String text)
	{
		cubesF.add(text);
	}
	
	/**
	 * Guarda los CubeRegionMember en una lista
	 */
	public void almacenaMemCub(String text)
	{
		memCubF.add(text);
	}
	
	/**
	 * Guarda los DimensionMember en una lista
	 */
	public void almacenaMemDim(String text)
	{
		memDimF.add(text);
	}
	
	/**
	 * Guarda los MemberPermission en una lista
	 */
	public void almacenaMemP(String text)
	{
		memPerF.add(text);
	}
	
	/**
	 *  Retorna true o false en funcion de si existe el rol que se pasa
	 */
	public boolean buscaRol(String text)
	{
		int c=0;

		Iterator i= rolesF.iterator();
		String aux ="";

		if( aux.equals(text) )
		{
			return true;
		}
		while(i.hasNext())
		{
			aux = (String) i.next();

			if( aux.equals(text) )
			{
				return true;
			}
			c++;
		}
		return false;
	}
	
	/**
	 *  Retorna true o false en funcion de si existe la dimension que se pasa
	 */
	public boolean buscaDim(String text)
	{
		int c=0;

		Iterator i= dimF.iterator();
		String aux ="";

		if( aux.equals(text) )
		{
			return true;
		}
		while(i.hasNext())
		{
			aux = (String) i.next();
			if( aux.equals(text) )
			{
				return true;
			}
			c++;
		}
		return false;
	}
	
	/**
	 *  Retorna true o false en funcion de si existe el cubo que se pasa
	 */
	public boolean buscaCub(String text)
	{
		int c=0;

		Iterator i= cubesF.iterator();
		String aux ="";

		if( aux.equals(text) )
		{
			return true;
		}
		while(i.hasNext())
		{
			aux = (String) i.next();
			if( aux.equals(text) )
			{
				return true;
			}
			c++;
		}
		return false;
	}
	
	/**
	 *  Retorna true o false en funcion de si existe el CubeRegionMember que se pasa
	 */
	public boolean buscaMemCub(String text)
	{
		int c=0;

		Iterator i= memCubF.iterator();
		String aux ="";

		if( aux.equals(text) )
		{
			return true;
		}
		while(i.hasNext())
		{
			aux = (String) i.next();
			if( aux.equals(text) )
			{
				return true;
			}
			c++;
		}
		return false;
	}
	
	/**
	 *  Retorna true o false en funcion de si existe el DimensionMember que se pasa
	 */
	public boolean buscaMemDim(String text)
	{
		int c=0;

		Iterator i= memDimF.iterator();
		String aux ="";

		if( aux.equals(text) )
		{
			return true;
		}
		while(i.hasNext())
		{
			aux = (String) i.next();
			if( aux.equals(text) )
			{
				return true;
			}
			c++;
		}
		return false;
	}
	
	/**
	 *  Retorna true o false en funcion de si existe el MemberPermission que se pasa
	 */
	public boolean buscaMemP(String text)
	{
		int c=0;

		Iterator i= memPerF.iterator();
		String aux ="";

		if( aux.equals(text) )
		{
			return true;
		}
		while(i.hasNext())
		{
			aux = (String) i.next();
			if( aux.equals(text) )
			{
				return true;
			}
			c++;
		}
		return false;
	}
	
	/**
	 * Asignar una posicion al rol dentro de la lista de ellos
	 */
	public int ponNumRol(String text)
	{
		int c=0, d=0;

		Iterator i= rolesF.iterator();
		String aux ="";

		while(i.hasNext())
		{
			aux = (String) i.next();

			if( aux.equals(text) )
			{
				d=c;
			}
			c++;
		}
		return d;
	}
	
	/**
	 * Asignar una posicion a la dimension dentro de la lista de ellas
	 */
	public int ponNumDim(String text)
	{
		int c=0, d=0;

		Iterator i= dimF.iterator();
		String aux ="";

		while(i.hasNext())
		{
			aux = (String) i.next();

			if( aux.equals(text) )
			{
				d=c;
			}
			c++;
		}
		return d;
	}
	
	/**
	 * Asignar una posicion al cubo dentro de la lista de ellos
	 */
	public List ponNumCub(String text)
	{
		LinkedList posCub = new LinkedList<Integer>();
		int x=-1;

		try{
			for (int numArch = 0; numArch < ListaArchivos.length; numArch++) {
				SAXBuilder builder = new SAXBuilder(false);
				Document doc = builder.build(ListaArchivos[numArch]);
				
				Element raiz = doc.getRootElement();
				String nomRaiz = raiz.getName();
		if(nomRaiz.equals("Cube"))
		{
			x++;
			int numCubs = raiz.getChildren().size();
			int v1=0, v2=0, v3=0;
			int cuReX = 0;
			licubR = new LinkedList<String>();
			licrM = new LinkedList<String>();
			Element cubeid = null, cubename = null, cubper = null, cubreg = null, cubdim = null; //Para cube
			Element cdid = null;
			//Element crmid = null,
			for(int i=0;i<numCubs;i++)
			{
				if( ((Element) raiz.getChildren().get(i)).getName().equals("ID") )
					cubeid = (Element) raiz.getChildren().get(i);
				
				//DIMENSION EN CUBE
				if( ((Element) raiz.getChildren().get(i)).getName().equals("Dimensions") )
				{
					cubdim = (Element) raiz.getChildren().get(i);
					List listcubdim = cubdim.getChildren();
					if(listcubdim.size() > 0)
					{
						Iterator i9 = listcubdim.iterator();
						
						while (i9.hasNext())
						{
							Element cd = (Element) i9.next();

							for(int j=0;j<cd.getChildren().size();j++)
							{
								if(((Element) cd.getChildren().get(j)).getName().equals("ID"))
								{

									cdid = (Element) cd.getChildren().get(j);
									if(cdid.getText().equals(text))
									{
										posCub.add(x);
									}
								}
								
							}//ffor cbreg
						}//fwhile i9
						
					}//fif listcubreg
				}//fif getName=MeasureGroups					
			}}}}
		catch(Exception e){}
		return posCub;
	}
	
	/**
	 * Asignar una posicion al CubeRegionMember dentro de la lista de ellos
	 */	
	public int ponNumMemCub(String text)
	{
		int c=0, d=0;

		Iterator i= memCubF.iterator();
		String aux ="";

		while(i.hasNext())
		{
			aux = (String) i.next();

			if( aux.equals(text) )
			{
				d=c;
			}
			c++;
		}
		return d;
	}
	
	/**
	 * Asignar una posicion al DimensionMember dentro de la lista de ellos
	 */
	public int ponNumMemDim(String text)
	{
		int c=0, d=0;

		Iterator i= memDimF.iterator();
		String aux ="";

		while(i.hasNext())
		{
			aux = (String) i.next();

			if( aux.equals(text) )
			{
				d=c;
			}
			c++;
		}
		return d;
	}
	
	/**
	 * Asignar una posicion al MemberPermission dentro de la lista de ellos
	 */
	public List<Integer> ponNumMemP(String text)
	{

		int c=0;
		LinkedList<Integer> d = new LinkedList<Integer>();

		Iterator i= memPerF.iterator();
		String aux ="";

		while(i.hasNext())
		{
			aux = (String) i.next();

			if( aux.equals(text) )
			{
				d.add(c);
			}
			c++;
		}
		return d;
	}
	
	/**
	 * Metodo auxiliar que inicializa roles, dimensiones y cubos,
	 * asi como sus elementos dependientes con el fin de facilitar la 
	 * busqueda de elementos y asignar las correspondencias del estilo
	 * xxxx.0, xxxx.1 ...
	 */
	public void iniciaTodo() throws IOException, JDOMException
	{
		int diaux=0;

		try{
		for (int numArch = 0; numArch < ListaArchivos.length; numArch++) {
			SAXBuilder builder = new SAXBuilder(false);
			Document doc = builder.build(ListaArchivos[numArch]);

			Element raiz = doc.getRootElement();
			String nomRaiz = raiz.getName();
			
			//------ROLES---------
			if(nomRaiz.equals("Role"))
			{
				int numRols = raiz.getChildren().size();
				Element rolid = null;
				for(int i=0;i<numRols;i++)
				{
					if( ((Element) raiz.getChildren().get(i)).getName().equals("ID") )
						rolid = (Element) raiz.getChildren().get(i);

				}//busqueda elems de rol

				almacenaRol(rolid.getText());

			}
			//-----CUBES
			if(nomRaiz.equals("Cube"))
			{
				int numCubs = raiz.getChildren().size();
				licubR = new LinkedList<String>();
				licrM = new LinkedList<String>();
				Element cubeid = null, cubename = null, cubper = null, cubreg = null, cubdim = null; //Para cube
				Element cubpid = null, cubpna = null, cubpro = null, cubpred = null; //Para cubePermission
				Element cbrid = null, cbrnam = null, cregmemb = null; //Para cubeRegion
				Element cbrmid = null, cbrmna = null; //Para CubeRegionMember
				Element cdid = null;
				//Element crmid = null, 
				for(int i=0;i<numCubs;i++)
				{
					if( ((Element) raiz.getChildren().get(i)).getName().equals("ID") )
						cubeid = (Element) raiz.getChildren().get(i);
					
					
					if( ((Element) raiz.getChildren().get(i)).getName().equals("MeasureGroups") )
					{
						//---------------CUBEREGION = MEASUREGROUPS
						cubreg = (Element) raiz.getChildren().get(i);
						List listcubreg = cubreg.getChildren();
						if(listcubreg.size() > 0)
						{
							Iterator i9 = listcubreg.iterator();
							
							
							while (i9.hasNext())
							{
								Element cbreg = (Element) i9.next();

								for(int j=0;j<cbreg.getChildren().size();j++)
								{
									if(((Element) cbreg.getChildren().get(j)).getName().equals("Measures"))
									{
										//-------------CUBEREGIONMEMBER = MEASURES
										cregmemb = (Element) cbreg.getChildren().get(j);
										List listcregmem = cregmemb.getChildren();
										
										if(listcregmem.size() > 0)
										{
											Iterator i10 = listcregmem.iterator();
											while (i10.hasNext())
											{
												Element cregmem = (Element) i10.next();

												for(int k=0;k<cregmem.getChildren().size();k++)
												{
													if(((Element) cregmem.getChildren().get(k)).getName().equals("ID"))
													{
														cbrmid = (Element) cregmem.getChildren().get(k);
													}
												}
												almacenaMemCub(cbrmid.getText());
											}//fwhile i10
										}//fif listcregmem
									}//fif Measures
								}//ffor cbreg

							}//fwhile i9
						}//fif listcubreg
					}//fif getName=MeasureGroups	
				}
				almacenaCub(cubeid.getText());
			}
			
			//------DIMENSION---------
			if(nomRaiz.equals("Dimension"))
			{
				int v1=0, v2=0, v3=0, v4=0,v5=0;
				
				lidimNT = new LinkedList<String>();
				lidip = new LinkedList<String>();
				lihi = new LinkedList<String>();
				lile = new LinkedList<String>();
			
				int numDims = raiz.getChildren().size();
				Element dimid = null, dimper = null, dimmem = null; //Para dimension
				Element dimpermid = null, dimpermname = null, dimpermrid = null, dimpermread = null, dimpermatt = null;
				Element dimmemid = null, dimmemna = null;
				Element memperid = null;
				
				int dima=0;


				for(int i=0;i<numDims;i++)
				{
					if( ((Element) raiz.getChildren().get(i)).getName().equals("ID") ){
						dimid = (Element) raiz.getChildren().get(i);
					}
					
					if( ((Element) raiz.getChildren().get(i)).getName().equals("DimensionPermissions") )
					{
						//------DIMENSIONPERMISSION
						dimper = (Element) raiz.getChildren().get(i);
						List listDimPer = dimper.getChildren();
						if(listDimPer.size() > 0)
						{
							Iterator i11 = listDimPer.iterator();
							
							while (i11.hasNext())
							{
								Element dimperms = (Element) i11.next();
								
								for(int j=0;j<dimperms.getChildren().size();j++)
								{
									if(((Element) dimperms.getChildren().get(j)).getName().equals("AttributePermissions"))
									{
										//-----MEMBERPERMISSION = ATTRIBUTEPERMISSION
										dimpermatt = (Element) dimperms.getChildren().get(j);
										List listmper = dimpermatt.getChildren();
										if(listmper.size() > 0)
										{
											Iterator i12 = listmper.iterator();
											while (i12.hasNext())
											{
												Element memperms = (Element) i12.next();
												//dimPermT+="//@AuxMemberPermissions."+numMemPer+" ";
												for(int k=0;k<memperms.getChildren().size();k++)
												{
													if(((Element) memperms.getChildren().get(k)).getName().equals("AttributeID"))
													{
														memperid = (Element) memperms.getChildren().get(k);
													}
												}//ffor numero mem perm
												//almacenaMemP(memperid.getText());
											}//fwhile iter MemPerm
										}//fif lista memperm
									}//fif nombre=AttributePermision
									
																
								}//ffor numero dimperm					
							}//fwhile dimPerm
							
						}//fif listDimPers
					}//fif getName=DimensionPermission
					
					if( ((Element) raiz.getChildren().get(i)).getName().equals("Attributes") )
					{
						//------DIMENSIONMEMBER = ATTRIBUTES
						dimmem = (Element) raiz.getChildren().get(i);
						List listDimMem = dimmem.getChildren();
						if(listDimMem.size() > 0)
						{
							Iterator i13 = listDimMem.iterator();
							while (i13.hasNext())
							{
								Element dimmems = (Element) i13.next();
								
								for(int j=0;j<dimmems.getChildren().size();j++)
								{
									if(((Element) dimmems.getChildren().get(j)).getName().equals("ID"))
									{
										dimmemid = (Element) dimmems.getChildren().get(j);
									}
								}
								almacenaMemDim(dimmemid.getText());
								dima++;
							}//fwhile iter8
						}//fif listDimMem
					}//fif getName=Attributes
					
				}
				tamDimF.put(diaux, dima);
				almacenaDim(dimid.getText());
				diaux++;
			}
			
			
			
		}}catch(Exception e){}
	}
	
	/**
	 * Clase auxiliar para asignar a un SecurityPermission
	 * todos sus atributos
	 */
	class SecPerm
	{
		LinkedList<String> lr = new LinkedList<String>();		
		LinkedList<String> lp = new LinkedList<String>();
		LinkedList<String> la = new LinkedList<String>();
		LinkedList<String> ld = new LinkedList<String>();
		LinkedList<String> lrol = new LinkedList<String>();
		LinkedList<String> li = new LinkedList<String>();
		LinkedList<String> ln = new LinkedList<String>();
		LinkedList<Integer> lm = new LinkedList<Integer>();

		LinkedList<LinkedList<MemPerm>> lmem = new LinkedList<LinkedList<MemPerm>>();

		LinkedList <Integer> lpos = new LinkedList<Integer>();
		
		/**
		 * Metodo para a�adir read
		 */
		public void read(String text, int i)
		{
			try{
				lr.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir process
		 */
		public void poSet(String text, int i)
		{
			try{
				lp.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir allowedSet
		 */
		public void alSet(String text, int i){
			try{
				la.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir deniedSet
		 */
		public void dnSet(String text, int i){
			try{
				ld.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir roles
		 */
		public void rolSet(String text, int i){
			lrol.add(i, text);
		}
		
		/**
		 * Metodo para a�adir ID
		 */
		public void idSet(String text, int i){
			li.add(i, text);
		}
		
		/**
		 * Metodo para a�adir nombres
		 */
		public void naSet(String text, int i){
			ln.add(i, text);
		}
		
		/**
		 * Metodo para a�adir Member
		 */
		public void tieneMem(int text, int i){
			lm.add(i, text);
		}
		
		/**
		 * Metodo para a�adir una lista de MemberPermission a un SecurityPermission

		 */
		public void memSet(LinkedList<MemPerm> text, int i){
			lmem.add(i, text);
		}
		
		/**
		 * Metodo para a�adir la posicion
		 */
		public void posicion(int num)
		{
			lpos.add(num);
		}
	}
	
	/**
	 * Clase auxiliar con el fin de asignar a un MemberPermission
	 * todos sus atributos
	 */
	class MemPerm
	{
		LinkedList<String> la = new LinkedList<String>();
		LinkedList<String> ld = new LinkedList<String>();
		LinkedList<String> ln = new LinkedList<String>();
		LinkedList<String> ldim = new LinkedList<String>();
		LinkedList<String> lrol = new LinkedList<String>();
		LinkedList<String> lmem = new LinkedList<String>();

		LinkedList <Integer> lpos = new LinkedList<Integer>();
		
		/**
		 * Metodo para a�adir allowedSet
		 */
		public void alSet(String text, int i){
			try{
				la.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir deniedSet
		 */
		public void dnSet(String text, int i){
			try{
				ld.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir ID
		 */
		public void naSet(String text, int i){
			try{
				ln.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir Attribute
		 */
		public void memSet(String text, int i){
			try{
				lmem.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir Dimension
		 */
		public void dimSet(String text, int i){
			try{
				ldim.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir roles
		 */
		public void rolSet(String text, int i){
			try{
				lrol.add(i, text);
			}catch(Exception e){}
		}
		
		/**
		 * Metodo para a�adir la posicion del SecurityPermission
		 */
		public void posicion(int num)
		{
			try{
				lpos.add(num);
			}catch(Exception e){}
		}
	}
	
	/**
	 * Reemplazar caracteres especiales como & por &amp, 
	 * por ejemplo, con el fin  de que el fichero generado 
	 * en la transformacion sea leido sin problemas

	 */
	public String reemplaza(String text)
	{
		//Si el texto contiene algo a reemplazar retorna lo nuevo
		if(text.contains("&"))
		{
			String cambio = text.replaceAll("&","&amp;");
			return cambio;
		}
		if(text.contains("<"))
		{
			String cambio = text.replaceAll("<","&lt;");
			return cambio;
		}
		if(text.contains(">"))
		{
			String cambio = text.replaceAll(">","&gt;");
			return cambio;
		}
		return text; //En caso de que llegue hasta aqui retorna el origen
	}
		
	

}
